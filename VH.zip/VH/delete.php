	<script src="sweetalert/sweetalert.js"></script>
	<script src="sweetalert/jquery.min.js"></script>
<?php 

// Database connection
$conn = new mysqli('localhost', 'aykxgbsgsh', 'C4Bgd7tAdV', 'aykxgbsgsh');
$id=$_GET['id'];

?>
	
	<?php
// Insert data Query
$sql = "DELETE from video_tbl WHERE Sno='$id'";

if ($conn->query($sql) === TRUE) {
   echo'<script type="text/javascript">
                            jQuery(function validation(){
                            swal("Success", "Success! Video Deleted", "success", {
                            button: "Continue",
							
                                }).then(()=>{
								
								window.location.href = "creator_videos.php";
								
								
								});
							});
                            </script>';
} 
?>