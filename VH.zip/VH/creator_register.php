<?php
   include_once'connect_db.php';
?>
  
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA==" crossorigin="anonymous" referrerpolicy="no-referrer" /> 
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
	<title>Creator Registration Form</title>
	<script src="sweetalert/sweetalert.js"></script>
	<script src="sweetalert/jquery.min.js"></script>
</head>
<style>
        Custom CSS for the About SMA section
        body {
            background-color: #f8f9fa;
            color: #495057;
            padding-top: 56px;
        }

        .navbar {
            background-color: #343a40;
        }

        .navbar-brand, .navbar-nav .nav-link {
            color: #ffffff !important;
        }

        .about-sma-container {
            background-color: #ffffff;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            padding: 30px;
            margin-top: 20px;
        }

        .about-sma-container h2 {
            color: #343a40;
        }

        .about-sma-container p {
            color: #6c757d;
        }
        
    </style>
<body>
<?php
    include("header.php");
    ?>
	<br><br>
    <div class="container-fluid mt-3">
        <h2 class="text-center mb-5">Creator Registration</h2>
        <div class="row d-flex justify-content-center">
            
            <div class="col-lg-12 col-xl-4">
                <form method="POST" action=""  enctype="multipart/form-data" autocomplete="off">
					<div class="form-outline mb-4">
                        <label for="username" class="form-label">Full Name</label>
                        <input type="text" class="form-control" id="name" name="name" placeholder="Enter Your Full Name" required>
                    </div>
                    <div class="form-outline mb-4">
                        <label for="username" class="form-label">Email</label>
                        <input type="text" class="form-control" id="email" name="email" placeholder="Enter Your Email" required>
                    </div>
                    <div class="form-outline mb-4">
                        <label for="Cnic" class="form-label">Contact#</label>
                        <input type="text" class="form-control" id="contact" name="contact" placeholder="Enter Your Contact#" required>
                    </div>
                    <div class="form-outline mb-4">
                        <label for="Owner_name" class="form-label">Address</label>
                        <input type="text" class="form-control" id="address" name="address" placeholder="Enter Your Address" required>
                    </div>
                    <div class="form-outline mb-4">
                        <label for="Owner_Contact" class="form-label">City</label>
                        <input type="text" class="form-control" id="city" name="city" placeholder="Enter Your City" required>
                    </div>
                    
                    <div class="form-group mb-4">
                    <label for="admin_img">Gender</label>
                    <select class="form-control" id="gender" name="gender">
						<option value="">--- Select Gender ---</option>
						<option value="Male">Male</option>
						<option value="Female">Female</option>
					</select>
                    </div>
                    
                    <div class="form-outline mb-4">
                        <label for="s_date" class="form-label">Password</label>
                        <input type="password" class="form-control" id="password" name="password" placeholder="Enter Password" required>
                    </div>
					
					<div class="form-outline mb-4">
						<p>Already Have Account? <a href="login.php">Login</a></p>
					</div>
					
                    <div class="form-outline mb-4">
                        <input type="submit" class="btn bg-info py-2 px-3 border-0" name="Register" value="Register">
                    </div>
                </form>
            </div>
        </div>
    </div><br><br>
    <footer>
    <?php
    include("footer.php");
    ?>
</footer>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>

</body>
</html>
<?php
	if(isset($_POST['Register'])){
        $name = $_POST['name'];
        $email = $_POST['email'];
        $contact = $_POST['contact'];
		$address = $_POST['address'];
        $city = $_POST['city'];
        $gender = $_POST['gender'];
        $password = $_POST['password'];
        $status = "Active";
        
		$insert = $pdo->prepare("INSERT INTO creator_tbl(Name,Email,Contact,Address,City,Gender,Password,Status)
                            values(:name,:email,:contact,:address,:city,:gender,:password,:status)");

                            $insert->bindParam(':name', $name);
                            $insert->bindParam(':email', $email);
                            $insert->bindParam(':contact', $contact);
                            $insert->bindParam(':address', $address);
                            $insert->bindParam(':city', $city);
                            $insert->bindParam(':gender', $gender);
                            $insert->bindParam(':password', $password);
                            $insert->bindParam(':status', $status);
                    
					if($insert->execute()){
						
                                echo'<script type="text/javascript">
                                        jQuery(function validation(){
                                        swal("Success", "Success! Registration Completed", "success", {
                                        button: "Continue",
										
                                            }).then(()=>{
											
											window.location.href = "creator_login.php";
											});
										});
                                        
										
                                        </script>';
										
                            }else{
                                echo '<script type="text/javascript">
                                        jQuery(function validation(){
                                        swal("Error", "Unable to Register. Please Try again Later.", "error", {
                                        button: "Continue",
                                            });
                                        });
                                        </script>';
                            }
		}
?>