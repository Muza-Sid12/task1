<?php
   include_once'connect_db.php';
   session_start();
   if(!isset($_SESSION['creator_id'])){
	  
	 echo "<script>if(confirm('Please Login to Continue.')){document.location.href='login.php'};</script>";
    
   }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA==" crossorigin="anonymous" referrerpolicy="no-referrer" /> 
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
	<title>Upload Video</title>
	<script src="sweetalert/sweetalert.js"></script>
	<script src="sweetalert/jquery.min.js"></script>
</head>
<style>
        /* Custom CSS for the About SMA section */
        body {
            background-color: #f8f9fa;
            color: #495057;
            padding-top: 56px;
        }

        .navbar {
            background-color: #343a40;
        }

        .navbar-brand, .navbar-nav .nav-link {
            color: #ffffff !important;
        }

        .about-sma-container {
            background-color: #ffffff;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            padding: 30px;
            margin-top: 20px;
        }

        .about-sma-container h2 {
            color: #343a40;
        }

        .about-sma-container p {
            color: #6c757d;
        }
        
    </style>
<body>
<?php
    include("header-user.php");
    ?>
	<br><br>
    <div class="container-fluid mt-3">
	
        <center><h2>Upload Video</h2>
		<a href="creator-dashboard.php"><p><b>Go Back</b></p></a></center>
        <div class="row d-flex justify-content-center">
            
            <div class="col-lg-8 col-xl-8">
                <form method="POST" action=""  enctype="multipart/form-data" autocomplete="off">
                    <div class="form-outline mb-4">
                        <label for="title" class="form-label">Title</label>
                        <input type="text" class="form-control" id="title" name="title" placeholder="Enter Video Title" required>
                    </div>
                    <div class="form-outline mb-4">
                        <label for="meta" class="form-label">Meta</label>
                        <input type="text" class="form-control" id="meta" name="meta" placeholder="Enter Meta" required>
                    </div>
                    <div class="form-outline mb-4">
                        <label for="hashtag" class="form-label">HashTag#1</label>
                        <input type="text" class="form-control" id="hashtag1" name="hashtag1" placeholder="Enter Hash Tag# 1" required>
                    </div>
					<div class="form-outline mb-4">
                        <label for="hashtag" class="form-label">HashTag#2</label>
                        <input type="text" class="form-control" id="hashtag2" name="hashtag2" placeholder="Enter Hash Tag# 2" required>
                    </div>
					<div class="form-outline mb-4">
                        <label for="hashtag" class="form-label">HashTag#3</label>
                        <input type="text" class="form-control" id="hashtag3" name="hashtag3" placeholder="Enter Hash Tag# 3" required>
                    </div>
					<div class="form-outline mb-4">
                        <label for="hashtag" class="form-label">HashTag#4</label>
                        <input type="text" class="form-control" id="hashtag4" name="hashtag4" placeholder="Enter Hash Tag# 4" required>
                    </div>
                   
                    
					
					<div class="form-group mb-4">
                    <label for="admin_img">Upload Video</label><br>
                    <input type="file" id="video" name="video">
					
                    </div>
                    
                    <div class="form-outline mb-4">
                        <input type="submit" class="btn bg-info py-2 px-3 border-0" name="Register" value="Upload">
                    </div>
                </form>
            </div>
        </div>
    </div>
    <br><br>
    <footer>
    <?php
    include("footer.php");
    ?>
</footer>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>

</body>
</html>
<?php
	if(isset($_POST['Register'])){
		$user_id="";
		if(isset($_SESSION['creator_id'])){
			$user_id=$_SESSION['creator_id'];
			
		}
		
		
		
        $title = $_POST['title'];
        $meta = $_POST['meta'];
        $hashtag1 = $_POST['hashtag1'];
		$hashtag2 = $_POST['hashtag2'];
        $hashtag3 = $_POST['hashtag3'];
        $hashtag4 = $_POST['hashtag4'];
        
        $status = "Active";
		
		
		$img = $_FILES['video']['name'];
            $img_tmp = $_FILES['video']['tmp_name'];
            $img_size = $_FILES['video']['size'];
            $img_ext = explode('.', $img);
            $img_ext = strtolower(end($img_ext));

            $img_new = uniqid().'.'. $img_ext;

            $store = "video/".$img_new;
		
		
		
		if(move_uploaded_file($img_tmp,$store)){
        
		$insert = $pdo->prepare("INSERT INTO video_tbl(Creator_Id,Title,Meta,Hashtag1,Hashtag2,Hashtag3,Hashtag4,Status,Video)
                            values(:user_id,:title,:meta,:hashtag1,:hashtag2,:hashtag3,:hashtag4,:status,:img_new)");

                            $insert->bindParam(':user_id', $user_id);
                            $insert->bindParam(':title', $title);
                            $insert->bindParam(':meta', $meta);
                            $insert->bindParam(':hashtag1', $hashtag1);
                            $insert->bindParam(':hashtag2', $hashtag2);
                            $insert->bindParam(':hashtag3', $hashtag3);
                            $insert->bindParam(':hashtag4', $hashtag4);
                            $insert->bindParam(':status', $status);
                            $insert->bindParam(':img_new', $img_new);

                    
					if($insert->execute()){
						
                                echo'<script type="text/javascript">
                                        jQuery(function validation(){
                                        swal("Success", "Success! Video Uploaded", "success", {
                                        button: "Continue",
										
                                            }).then(()=>{
											
											window.location.href = "creator-dashboard.php";
											});
										});
                                        
										
                                        </script>';
										
                            }else{
                                echo '<script type="text/javascript">
                                        jQuery(function validation(){
                                        swal("Error", "Unable to Upload Video. Please Try again Later.", "error", {
                                        button: "Continue",
                                            });
                                        });
                                        </script>';
                            }
		}
		}
?>