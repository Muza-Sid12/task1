<?php
   include_once'connect_db.php';
   session_start();
?>
  
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA==" crossorigin="anonymous" referrerpolicy="no-referrer" /> 
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
	<title>Creator Login Form</title>
	<script src="sweetalert/sweetalert.js"></script>
	<script src="sweetalert/jquery.min.js"></script>
	<style>
        /* Custom CSS for the About SMA section */
        body {
            background-color: #f8f9fa;
            color: #495057;
            padding-top: 56px;
        }

        .navbar {
            background-color: #343a40;
        }

        .navbar-brand, .navbar-nav .nav-link {
            color: #ffffff !important;
        }

        .about-sma-container {
            background-color: #ffffff;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            padding: 30px;
            margin-top: 20px;
        }

        .about-sma-container h2 {
            color: #343a40;
        }

        .about-sma-container p {
            color: #6c757d;
        }
        
    </style>
</head>
<style>
    
</style>
<body>
<?php
    include("header.php");
    ?>
	<br><br>
    <div class="container-fluid mt-3">
        <h2 class="text-center mb-5">Creator Login</h2>
        <div class="row d-flex justify-content-center">
            
            <div class="col-lg-12 col-xl-4">
                <form method="POST" action=""  enctype="multipart/form-data" autocomplete="off">
					
                    <div class="form-outline mb-4">
                        <label for="username" class="form-label">Email</label>
                        <input type="text" class="form-control" id="email" name="email" placeholder="Enter Your Email" required>
                    </div>
                   
                    <div class="form-outline mb-4">
                        <label for="s_date" class="form-label">Password</label>
                        <input type="password" class="form-control" id="password" name="password" placeholder="Enter Password" required>
                    </div>
					
					<div class="form-outline mb-4">
						<p>Dn't Have Account? <a href="creator_register.php">Register</a></p>
					</div>
					
					
                    <div class="form-outline mb-4">
                        <input type="submit" class="btn bg-info py-2 px-3 border-0" name="Login" value="Login">
                    </div>
                </form>
            </div>
        </div>
    </div><br><br>
    <footer>
    <?php
    include("footer.php");
    ?>
</footer>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>

</body>
</html>
<?php

if(isset($_POST['Login'])){
	
		$email = $_POST['email'];
		$password = $_POST['password'];
		
		
		$select_login = $pdo->prepare("select * from creator_tbl where Email='$email'");
    $select_login->execute();
    $row_login = $select_login->fetch(PDO::FETCH_ASSOC);

    if($password==$row_login['Password']){
        $_SESSION['creator_id']=$row_login['Sno'];
		$_SESSION['creator_name']=$row_login['Name'];
        $_SESSION['creator_email']=$row_login['Email'];
        

        echo'<script type="text/javascript">
              jQuery(function validation(){
                swal("Login Success", "Welcome '.$_SESSION['creator_name'].'", "success", {
                    button: "Continue",
                    })
					.then(()=>{
					window.location.href = "creator-dashboard.php";
					});
                });
              </script>';
        

    }else {
		echo'<script type="text/javascript">
             jQuery(function validation(){
            swal("Login Fail", "Unable to Login Try Again", "error", {
            button: "Continue",
                })
				.then(()=>{
				
				window.location.href = "creator_login.php";
				
				});
            });
          </script>';
		
}
}

?>