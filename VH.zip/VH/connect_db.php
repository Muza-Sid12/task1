<?php
try{
    // $pdo = new PDO('mysql:host=localhost;dbname=videohub_db','root','');
    // //echo 'Connection Successfull';

    //new changes
    $host = getenv('MYSQL_SERVER') ?: 'localhost';
    $dbname = getenv('MYSQL_DATABASE') ?: 'videohub_db';
    $username = getenv('MYSQL_USERNAME') ?: 'root';
    $password = getenv('MYSQL_PASSWORD') ?: '';

    // For Azure MySQL, we need to specify SSL and port
    // $options = array(
    //     PDO::MYSQL_ATTR_SSL_CA => '/etc/ssl/certs/Baltimore_CyberTrust_Root.crt',
    //     PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
    // );

    $pdo = new PDO(
        "mysql:host=$host;dbname=$dbname;charset=utf8mb4",
        $username,
        $password
        // $options
    );
}catch(PDOException $error){
    echo $error->getmessage();
}
 

//try{
    //$pdo = new PDO('mysql:host=localhost;dbname=aykxgbsgsh','aykxgbsgsh','C4Bgd7tAdV');
    //echo 'Connection Successfull';
//}catch(PDOException $error){
//    echo $error->getmessage();
//}


?>